# Minecraft Server Website Template!
A website template for your Minecraft server!


To use the website template you just have to download the files. Then you adjust everything in each .html file, i.e. the email and all the content. Then all you have to do is upload the files to your web server. Importantly, in the file "apply.html" it must be stated in line 33 in the email to which email the completed applications should be sent. If you have any questions, please contact me on Discord: BlackNight#3906!

![image](https://github.com/RexFracht868454/MinecraftServerWebsite/assets/88945501/de303d98-fed3-4d7b-9b40-bc2568e5b654)
![image](https://github.com/RexFracht868454/MinecraftServerWebsite/assets/88945501/d4fe422c-6b3e-4dab-b0ef-1121657398e6)
![image](https://github.com/RexFracht868454/MinecraftServerWebsite/assets/88945501/ff105ac3-a2ca-4c6a-9451-8403c431a5b1)
![image](https://github.com/RexFracht868454/MinecraftServerWebsite/assets/88945501/79974649-0510-4fbf-a9fb-bfd8d7de9d78)

Original from [Skaustly](https:///www.spigotmc.org/resources/mineweb-ger-de-minecraft-website-free.45084/), minimal revised and adapted by me!
